Cerberus SDK Libraries
======================

Binary libraries are provided upon account activation.

After completing setup in your dashboard (https://cerberusac.dev/dashboard),
the following libraries will be available for download:

  cerberus_sdk.lib      - Windows static library (MSVC)
  cerberus_sdk.dll      - Windows dynamic library
  cerberus_sdk_d.lib    - Windows debug static library
  cerberus_sdk_d.dll    - Windows debug dynamic library

Engine Plugins:
  CerberusUE5Plugin/    - Unreal Engine 5 plugin
  CerberusUnity/        - Unity 6 package
  CerberusGodot/        - Godot 4.x GDExtension

Contact support@cerberusac.dev if you need libraries for a different platform.
