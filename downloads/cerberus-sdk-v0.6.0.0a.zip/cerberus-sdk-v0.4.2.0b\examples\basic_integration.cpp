/**
 * Cerberus SDK - Basic Integration Example
 *
 * Demonstrates minimal setup for integrating Cerberus
 * anti-cheat into a game server or client.
 */

#include "../include/cerberus_sdk.h"
#include <stdio.h>
#include <stdlib.h>

/* Detection callback — called when a cheat is detected */
void onDetection(const CerberusDetection* detection, void* userData) {
    printf("[Cerberus] Detection: type=%d layer=%u confidence=%.1f%%\n",
           detection->type, detection->layer, detection->confidence * 100.0f);

    if (detection->confidence > 0.95f) {
        printf("[Cerberus] High-confidence detection — auto-ban triggered\n");
        /* Your game's ban logic here */
    }
}

int main(int argc, char* argv[]) {
    printf("Cerberus SDK %s - Basic Integration Example\n\n", cerberus_version());

    /* Configure the SDK */
    CerberusConfig config = {0};
    config.apiKey = "your_api_key_here";  /* Replace with your API key from dashboard */
    config.region = CERBERUS_REGION_AUTO; /* Auto-select closest region */
    config.layers = CERBERUS_LAYER_ALL;   /* Enable all licensed layers */
    config.autoEnforce = true;            /* Auto-ban on high-confidence detections */
    config.telemetryEnabled = true;
    config.heartbeatIntervalMs = 30000;   /* 30-second heartbeat */

    /* Initialize */
    CerberusResult result = cerberus_init(&config);
    if (result != CERBERUS_OK) {
        printf("Failed to initialize: %s\n", cerberus_error_string(result));
        return 1;
    }
    printf("Cerberus initialized successfully.\n");

    /* Set detection callback */
    cerberus_set_detection_callback(onDetection, NULL);

    /* Start a player session */
    CerberusSession session = {0};
    result = cerberus_session_start(&session, "player_12345");
    if (result != CERBERUS_OK) {
        printf("Failed to start session: %s\n", cerberus_error_string(result));
        cerberus_shutdown();
        return 1;
    }
    printf("Session started: ID=%llu\n", (unsigned long long)session.sessionId);

    /* Game loop simulation */
    printf("\nRunning game loop (session scans happen automatically)...\n");
    printf("Press Ctrl+C to exit.\n\n");

    /* In a real game, this would be your main loop.
     * The SDK runs scans automatically in a background thread.
     * You only need to call cerberus_session_heartbeat() periodically
     * to keep the session alive. */

    /* Check verdict at any time */
    float confidence = 0.0f;
    cerberus_get_verdict(&session, &confidence);
    printf("Current verdict confidence: %.2f%%\n", confidence * 100.0f);

    /* Cleanup */
    cerberus_session_end(&session);
    cerberus_shutdown();

    printf("Cerberus shutdown complete.\n");
    return 0;
}
