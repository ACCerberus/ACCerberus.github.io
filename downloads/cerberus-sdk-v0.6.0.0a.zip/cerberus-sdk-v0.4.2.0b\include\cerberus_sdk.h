/**
 * Cerberus Anti-Cheat SDK
 * Version: 0.4.2.0-beta
 *
 * Copyright 2024-2026 Cerberus Security Systems
 * All rights reserved. See LICENSE.txt for terms.
 *
 * Integration Guide: https://cerberusac.dev/sdk
 * API Reference: https://cerberusac.dev/docs
 */

#ifndef CERBERUS_SDK_H
#define CERBERUS_SDK_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

/* ═══════════════════════════════════════════
 * Version Info
 * ═══════════════════════════════════════════ */
#define CERBERUS_VERSION_MAJOR 0
#define CERBERUS_VERSION_MINOR 4
#define CERBERUS_VERSION_PATCH 2
#define CERBERUS_VERSION_BUILD 0
#define CERBERUS_VERSION_STRING "0.4.2.0b"

/* ═══════════════════════════════════════════
 * Result Codes
 * ═══════════════════════════════════════════ */
typedef enum {
    CERBERUS_OK = 0,
    CERBERUS_ERROR_INVALID_KEY = -1,
    CERBERUS_ERROR_NETWORK = -2,
    CERBERUS_ERROR_TIMEOUT = -3,
    CERBERUS_ERROR_NOT_INITIALIZED = -4,
    CERBERUS_ERROR_ALREADY_INITIALIZED = -5,
    CERBERUS_ERROR_SESSION_LIMIT = -6,
    CERBERUS_ERROR_REGION_UNAVAILABLE = -7,
    CERBERUS_ERROR_LAYER_NOT_LICENSED = -8,
    CERBERUS_ERROR_DRIVER_LOAD = -9,
    CERBERUS_ERROR_INTERNAL = -100
} CerberusResult;

/* ═══════════════════════════════════════════
 * Regions
 * ═══════════════════════════════════════════ */
typedef enum {
    CERBERUS_REGION_US_EAST = 0,
    CERBERUS_REGION_US_WEST = 1,
    CERBERUS_REGION_US_CENTRAL = 2,
    CERBERUS_REGION_EU_WEST = 3,
    CERBERUS_REGION_EU_CENTRAL = 4,
    CERBERUS_REGION_EU_NORTH = 5,
    CERBERUS_REGION_AP_SOUTHEAST = 6,
    CERBERUS_REGION_AUTO = 99
} CerberusRegion;

/* ═══════════════════════════════════════════
 * Detection Layers
 * ═══════════════════════════════════════════ */
#define CERBERUS_LAYER_KERNEL     (1 << 0)  /* Layer 1: Kernel Integrity */
#define CERBERUS_LAYER_AI         (1 << 1)  /* Layer 2: Behavioral AI */
#define CERBERUS_LAYER_HARDWARE   (1 << 2)  /* Layer 3: Hardware Fingerprinting */
#define CERBERUS_LAYER_NETWORK    (1 << 3)  /* Layer 4: Network Sentinel */
#define CERBERUS_LAYER_CUSTOM     (1 << 4)  /* Layer 5: Custom Rules (Olympus only) */
#define CERBERUS_LAYER_ALL        0x0F      /* Layers 1-4 */

/* ═══════════════════════════════════════════
 * Configuration
 * ═══════════════════════════════════════════ */
typedef struct {
    const char*     apiKey;
    CerberusRegion  region;
    uint32_t        layers;
    bool            autoEnforce;
    bool            telemetryEnabled;
    uint32_t        heartbeatIntervalMs;
    const char*     webhookUrl;
    void*           reserved;
} CerberusConfig;

/* ═══════════════════════════════════════════
 * Session
 * ═══════════════════════════════════════════ */
typedef struct {
    uint64_t    sessionId;
    uint64_t    startTime;
    uint32_t    scanCount;
    uint32_t    detectionCount;
    uint32_t    flags;
    void*       internal;
} CerberusSession;

/* ═══════════════════════════════════════════
 * Detection Event
 * ═══════════════════════════════════════════ */
typedef enum {
    CERBERUS_DETECTION_AIMBOT = 1,
    CERBERUS_DETECTION_ESP = 2,
    CERBERUS_DETECTION_SPEEDHACK = 3,
    CERBERUS_DETECTION_MEMORY_TAMPER = 4,
    CERBERUS_DETECTION_DRIVER_EXPLOIT = 5,
    CERBERUS_DETECTION_INJECTION = 6,
    CERBERUS_DETECTION_SIGNATURE_MATCH = 7,
    CERBERUS_DETECTION_HWID_SPOOF = 8,
    CERBERUS_DETECTION_PACKET_TAMPER = 9,
    CERBERUS_DETECTION_BEHAVIOR_ANOMALY = 10
} CerberusDetectionType;

typedef struct {
    CerberusDetectionType type;
    uint32_t              layer;
    float                 confidence;
    uint64_t              timestamp;
    const char*           details;
} CerberusDetection;

/* Callback for real-time detection events */
typedef void (*CerberusDetectionCallback)(const CerberusDetection* detection, void* userData);

/* ═══════════════════════════════════════════
 * Core API
 * ═══════════════════════════════════════════ */
CerberusResult cerberus_init(const CerberusConfig* config);
CerberusResult cerberus_shutdown(void);
const char*    cerberus_version(void);
const char*    cerberus_error_string(CerberusResult result);

/* ═══════════════════════════════════════════
 * Session Management
 * ═══════════════════════════════════════════ */
CerberusResult cerberus_session_start(CerberusSession* session, const char* playerId);
CerberusResult cerberus_session_end(CerberusSession* session);
CerberusResult cerberus_session_heartbeat(CerberusSession* session);
CerberusResult cerberus_session_scan(CerberusSession* session);

/* ═══════════════════════════════════════════
 * Detection
 * ═══════════════════════════════════════════ */
CerberusResult cerberus_set_detection_callback(CerberusDetectionCallback callback, void* userData);
CerberusResult cerberus_get_verdict(CerberusSession* session, float* confidence);
CerberusResult cerberus_report_player(const char* playerId, const char* reason);

/* ═══════════════════════════════════════════
 * Ban Management
 * ═══════════════════════════════════════════ */
CerberusResult cerberus_ban_player(const char* playerId, const char* reason);
CerberusResult cerberus_unban_player(const char* playerId);
CerberusResult cerberus_check_ban(const char* playerId, bool* isBanned);

#ifdef __cplusplus
}
#endif

#endif /* CERBERUS_SDK_H */
