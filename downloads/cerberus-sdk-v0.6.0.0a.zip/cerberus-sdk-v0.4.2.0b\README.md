# Cerberus Anti-Cheat SDK v0.4.2.0b

## Quick Start

1. Add `include/` to your project's include path
2. Link against `lib/cerberus_sdk` for your platform
3. Initialize the SDK with your API key:

```cpp
#include "cerberus_sdk.h"

int main() {
    CerberusConfig config;
    config.apiKey = "your_api_key_here";
    config.region = CERBERUS_REGION_US_EAST;
    config.layers = CERBERUS_LAYER_ALL;

    CerberusResult result = cerberus_init(&config);
    if (result != CERBERUS_OK) {
        // Handle initialization error
        return 1;
    }

    // Start a player session
    CerberusSession session;
    cerberus_session_start(&session, player_id);

    // Your game loop...

    cerberus_session_end(&session);
    cerberus_shutdown();
    return 0;
}
```

## Documentation

Full API reference: https://cerberusac.dev/docs
SDK integration guide: https://cerberusac.dev/sdk

## Support

Dashboard: https://cerberusac.dev/dashboard
Status: https://cerberusac.dev/status

## Requirements

- Windows 10/11 (64-bit)
- Visual Studio 2019+ or MinGW-w64
- .NET 6.0+ (for C# bindings)
- Unreal Engine 5.x / Unity 6.x / Godot 4.x (engine plugins)

## License

Proprietary - see LICENSE.txt for terms.
Copyright 2024-2026 Cerberus Security Systems. All rights reserved.
